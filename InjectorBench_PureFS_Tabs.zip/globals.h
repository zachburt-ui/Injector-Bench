
#pragma once
// ---- Common includes and shared types ----
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <Preferences.h>
#include <ESPmDNS.h>

// ---- Pins (see pins.h) ----
#include "pins.h"

// ---- Globals ----
extern Preferences prefs;
extern WebServer server;

// WiFi state
extern String sta_ssid;
extern String sta_pass;
extern IPAddress staIP, apIP;

// Telemetry & Settings model
struct Telemetry {
  float voltage;
  float pressure;
  float tempC;
  float rho;
};
struct Settings {
  bool  scales_on;
  float targetMl;
  float psi_nom;
  float volt_nom;
  char  fluid[16];
};

extern Telemetry telem;
extern Settings  settings;
extern float     scales_vals[8];

// ---- Prototypes used across tabs ----
void startAP();
bool connectSTA(unsigned long timeoutMs=15000);
void loadSettingsFromNVS();
void saveSettingsToNVS();
void wireStaticRoutes();
void wireApiRoutes();
String readBody();
void sendOK();
