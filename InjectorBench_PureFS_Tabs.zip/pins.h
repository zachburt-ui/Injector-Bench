
#pragma once
// Central place to map hardware pins (edit to match your build)

// Example injector outputs (placeholder)
#define PIN_INJ_1  16
#define PIN_INJ_2  17
#define PIN_INJ_3  18
#define PIN_INJ_4  19
#define PIN_INJ_5  21
#define PIN_INJ_6  22
#define PIN_INJ_7  23
#define PIN_INJ_8  25

// Example sense pins (placeholder)
#define PIN_VSENSE 34
#define PIN_PSENSE 35
#define PIN_TSENSE 36
