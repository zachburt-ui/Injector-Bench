InjectorBench V4 — Final Copy (no gzip)
======================================

FILES
-----
- v4.ino       : Firmware (ESP32 + WebServer + LittleFS). One-hot Static/Dynamic/Characterize, Clean multi-fire.
- index.html   : Single-page UI (tabs, injector pills, Characterize, Reports). No gzip. Works from LittleFS root.
- README.txt   : This file.

HARD RULES (applied)
--------------------
- Only v4.ino and index.html. No .gz anywhere.
- Stop finishes the current cycle (remaining selected injectors complete before halt).
- One injector at a time for Static/Dynamic/Characterize; Clean may multi-fire.
- Injector selection pills with hidden checkboxes; Select All/None; persisted to settings.json.
- Characterize tab restored with: PW sweep, Frequency sweep, Minimum PW, Repeatability, Voltage Offset vs V.
- Characterize supports: AUTO (scales stub), Quick Cal (virtual full), MANUAL (per-cell mL entry).
- Manual dump workflow; bench prompts via /api/characterize/dump.
- Reports tab aggregates last session, generates CSV; P59 + Holley copy-ready tables (IFR, Offset vs V, SPA).
- Clear Last Session button wipes session only when confirming "CLEAR".

ENDPOINTS (brief)
-----------------
GET  /                 -> index.html
GET  /api/ping         -> "ok"
GET  /api/sys          -> JSON (ssid, ip, build, settings)
GET  /api/settings     -> JSON (persisted)
POST /api/settings     -> JSON (injMask, pressurePsi, fluid, rho, assumedV)

POST /api/static/start -> {assist,targetMl,mode}
POST /api/static/markFull
POST /api/static/stop

POST /api/dynamic/start-> {pw,hz,sec}
POST /api/dynamic/stop

POST /api/clean/start  -> {pat,sec}
POST /api/clean/stop

POST /api/characterize/start -> {test,mode,dumpPolicy,dumpN,dumpX,pwStart,pwEnd,pwStep,hz,sec}
POST /api/characterize/stop
POST /api/characterize/dump
POST /api/characterize/enterMl -> {step,inj,ml}

GET  /api/report/csv   -> session CSV (Excel-friendly)
GET  /api/report/p59   -> text block (copy-ready fields)
GET  /api/report/hol   -> text block (copy-ready fields)
POST /api/session/clear

NOTES
-----
- Scales/voltage hardware are stubbed; AUTO mode remains selectable but relies on Quick Cal or Manual until wired.
- IFR, Offset vs V, SPA are filled from characterized data if present; otherwise placeholders are emitted with headers.
- Pins default to {25,26,27,14,12,13,32,33}; change injPins[] if your board differs.
