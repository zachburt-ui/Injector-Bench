#pragma once
// ==== SENSOR / TELEMETRY STUBS (to implement on ESP32) ====
// Provides: voltage, pressure, temp (MAX31865 RTD), scales[8]
// Expose telemetry at GET /api/telemetry -> { voltage, pressure, tempC, rho, scales:[g0..g7] }

struct Telemetry {
  float voltage;   // V
  float pressure;  // psi
  float tempC;     // degC from MAX31865 (PT100)
  float rho;       // g/mL for fluid
  float scales[8]; // grams per scale
};

void sensors_begin();                   // init ADCs / MAX31865 / HX711
void sensors_update();                  // poll & filter
Telemetry sensors_read();               // return last snapshot

void scales_tare_all();                 // set current raw to 0 for all channels
void scales_cal_all(float knownMassG);  // adjust scale factors so known mass reads correctly

void cal_set_voltage(float refV_reading, float refV_actual);   // set linear fit a,b
void cal_set_pressure(float refPsi_reading, float refPsi_actual);
