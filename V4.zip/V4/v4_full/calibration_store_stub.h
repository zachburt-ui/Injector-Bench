#pragma once
// ==== CALIBRATION STORAGE (Preferences) ====
// Suggested keys: "calV_a","calV_b","calP_a","calP_b","rho","targetMl","scales_on"

struct CalStore {
  float calV_a=1.0f, calV_b=0.0f;   // voltage linear (scaledV = a*raw + b)
  float calP_a=1.0f, calP_b=0.0f;   // pressure linear (psi = a*raw + b)
  float rho=0.745f;                 // g/mL for fluid
  float targetMl=100.0f;            // per test point
  bool  scales_on=true;
};

void cal_load(CalStore& c);
void cal_save(const CalStore& c);
